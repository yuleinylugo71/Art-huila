// i18n.js - Multilingual support (HU-SEO-02)
const i18nConfig = {
  lng: localStorage.getItem('language') || 'es',
  fallbackLng: 'es',
  debug: false,
  backend: {
    loadPath: '/locales/{{lng}}/translation.json',
  }
};

async function initI18n() {
  await i18next
    .use(i18nextHttpBackend)
    .use(i18nextBrowserLanguageDetector)
    .init(i18nConfig);
  
  translatePage();
}

function translatePage() {
  const elements = document.querySelectorAll('[data-i18n]');
  elements.forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = i18next.t(key);
  });
}

function changeLanguage(lng) {
  i18next.changeLanguage(lng, () => {
    localStorage.setItem('language', lng);
    translatePage();
    // Update active state on buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('onclick').includes(lng));
    });
  });
}

// Global helper for JS strings
function t(key) {
  return i18next.t(key);
}

// Auto init if i18next is loaded
if (typeof i18next !== 'undefined') {
  initI18n();
}
