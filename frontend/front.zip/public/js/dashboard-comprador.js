if (!Auth.getToken()) window.location.href = '/login.html';

const user = Auth.getUser();
document.getElementById('user-name').textContent = user.full_name;
document.getElementById('user-email').textContent = user.email;

document.addEventListener('DOMContentLoaded', () => {
    loadOrders();
    loadProfileData();
    updateNavCart();
});

function loadProfileData() {
    const user = Auth.getUser();
    document.getElementById('edit-full-name').value = user.full_name;
    document.getElementById('edit-email').value = user.email;
}

document.getElementById('profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Guardando...';

    const full_name = document.getElementById('edit-full-name').value;
    const password = document.getElementById('edit-password').value;

    const body = { full_name };
    if (password) body.password = password;

    try {
        const updatedUser = await apiFetch('/users/me', {
            method: 'PATCH',
            body: JSON.stringify(body)
        });
        
        // Update local storage and UI
        localStorage.setItem('art_huila_user', JSON.stringify(updatedUser));
        document.getElementById('user-name').textContent = updatedUser.full_name;
        showToast('✅ Perfil actualizado correctamente', 'success');
        document.getElementById('edit-password').value = '';
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
});

async function loadOrders() {
    const container = document.getElementById('orders-container');
    try {
        const orders = await apiFetch('/orders');
        if (orders.length === 0) {
            container.innerHTML = '<div class="empty-state"><h3>No has realizado pedidos aún.</h3><p>Explora nuestro catálogo y apoya a los artesanos locales.</p><a href="/catalogo.html" class="btn btn-primary mt-2">Ver catálogo</a></div>';
            return;
        }

        container.innerHTML = orders.map(order => `
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <div style="font-weight: bold;">Pedido #${order.id.substring(0, 8)}</div>
                        <div style="font-size: 0.85rem; color: var(--color-muted);">${new Date(order.created_at).toLocaleDateString()}</div>
                    </div>
                    <div style="text-align: right;">
                        <div class="badge ${getStatusBadge(order.status)}">${translateStatus(order.status)}</div>
                        <div style="font-weight: bold; color: var(--color-primary); margin-top: 0.25rem;">$${Number(order.total_amount).toLocaleString('es-CO')}</div>
                    </div>
                </div>
                <div class="order-items">
                    ${order.items.map(item => `
                        <div class="order-item">
                            <img src="${item.product.images[0]?.url || '/img/placeholder.jpg'}" alt="${item.product.name}" />
                            <div style="flex: 1;">
                                <div style="font-weight: 500;">${item.product.name}</div>
                                <div style="font-size: 0.85rem; color: var(--color-muted);">Cantidad: ${item.quantity} | Precio: $${Number(item.unit_price).toLocaleString('es-CO')}</div>
                            </div>
                            ${order.status === 'delivered' ? `
                                <a href="/producto.html?slug=${item.product.slug}#reviews-section" class="btn btn-ghost btn-sm">⭐ Calificar</a>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    } catch (e) {
        container.innerHTML = `<div class="error-msg">Error al cargar pedidos: ${e.message}</div>`;
    }
}

function getStatusBadge(status) {
    const map = {
        'pending': 'badge-pending',
        'paid': 'badge-verified',
        'shipped': 'badge-info',
        'delivered': 'badge-success',
        'cancelled': 'badge-danger'
    };
    return map[status] || '';
}

function translateStatus(status) {
    const map = {
        'pending': 'Pendiente',
        'paid': 'Pagado',
        'shipped': 'Enviado',
        'delivered': 'Entregado',
        'cancelled': 'Cancelado'
    };
    return map[status] || status;
}

window.showTab = function(tabName) {
    document.getElementById('tab-orders').style.display = tabName === 'orders' ? 'block' : 'none';
    document.getElementById('tab-profile').style.display = tabName === 'profile' ? 'block' : 'none';
    
    // Update active class in menu
    const links = document.querySelectorAll('.sidebar-menu a');
    links.forEach(l => l.classList.remove('active'));
    if (event && event.currentTarget) {
        event.currentTarget.classList.add('active');
    } else {
        // Find link by tabName if no event
        const selector = tabName === 'orders' ? 'Mis Pedidos' : 'Perfil';
        links.forEach(l => { if(l.textContent.includes(selector)) l.classList.add('active'); });
    }
}

function updateNavCart() {
    const cart = Cart.get();
    const count = cart.reduce((acc, item) => acc + item.quantity, 0);
    const badge = document.getElementById('nav-cart-count');
    if (badge) badge.textContent = `Carrito (${count})`;
}
